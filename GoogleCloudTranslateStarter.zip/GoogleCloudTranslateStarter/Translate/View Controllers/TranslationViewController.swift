//
//  TranslationViewController.swift
//  Translate
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import UIKit

class TranslationViewController: UIViewController {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var textView: UITextView!
    
    
    // MARK: - Properties
    
    var alertCollection: GTAlertCollection!
    
    
    
    // MARK: - Default Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
        alertCollection = GTAlertCollection(withHostViewController: self)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
        textView.text = ""
    }
    
    
    
    deinit {
        alertCollection = nil
    }
    
    
    
}
